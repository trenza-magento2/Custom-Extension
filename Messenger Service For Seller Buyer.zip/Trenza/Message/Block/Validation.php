<?php
namespace Trenza\Message\Block;
class Validation extends \Magento\Framework\View\Element\Template
{
		
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		array $data = []
    ) {
        parent::__construct($context, $data);
	}
	
	protected function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
   
}